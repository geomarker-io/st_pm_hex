library(testthat)
library(grf)

# This treats warnings as errors
options(warn = 2)
test_check("grf")
